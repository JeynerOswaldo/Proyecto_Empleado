package mundo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Empleado {

	/* -----------------------------------------------------------------
     								Atributos
     -------------------------------------------------------------------*/

	private String nombreEmpleado;
	private String apellidoEmpleado;
	private int genero; // 1 Femenino || 2 Masculino
	private String imagen;
	private double salario;
	private Fecha fechaNacimiento;
	private Fecha fechaIngreso;


	/* -----------------------------------------------------------------
						           Mètodos
	-------------------------------------------------------------------*/

	public Empleado() {

		nombreEmpleado="";
		apellidoEmpleado="";
		genero= 0;
		imagen="";
		salario = 0.0;
		fechaNacimiento= new Fecha();
		fechaIngreso=new Fecha();
	}

	public Empleado (String pNombreEmpleado, String pApellidoEmpleado, int pGenero,
			String pImagen, double pSalario, Fecha pFechaN, Fecha pFechaI ) {

		nombreEmpleado= pNombreEmpleado;
		apellidoEmpleado= pApellidoEmpleado;
		genero= pGenero;
		imagen= pImagen;
		salario = pSalario;
		fechaNacimiento= pFechaN;
		fechaIngreso=pFechaI;
	}


	/* metodos analizadores permiten obtener o modificar la informacion de los atributos
	 getters obtener y setters cambiar o modificar*/

	/* -----------------------------------------------------------------
					     metodos analizadores getters
	-------------------------------------------------------------------*/

	public String getNombre() {
		return nombreEmpleado;	
	}

	public String getApellido() {
		return apellidoEmpleado;
	}

	public int getGenero() {
		return genero;
	}

	public String getFechaNacimiento() {
		String strFecha = fechaNacimiento.toString( );
		return strFecha;
	}

	public String getFechaIngreso() {
		String strFecha = fechaIngreso.toString( );
		return strFecha;
	}
	public String Imagen() {
		return imagen;

	}
	public double Salario() {
		return salario;
	}


	/* --------------------------------------------------------------------
	             Metodo funcional calcule la fecha actual.
	-----------------------------------------------------------------------*/	

	public Fecha getFechaActual() {

		GregorianCalendar gc= new GregorianCalendar();

		int dia = gc.get(Calendar.DAY_OF_MONTH);
		int mes = gc.get(Calendar.MONTH) + 1;
		int anhio = gc.get(Calendar.YEAR);
		Fecha fechaActual = new Fecha( dia, mes, anhio);

		return fechaActual;
	}


	/* --------------------------------------------------------------------
	         	Metodo funcional calcule la antiguedad del empleado
	-----------------------------------------------------------------------*/	

	public int calcularAntiguedad() {

		Fecha fechaActual =getFechaActual( );
		int antiguedad=0;
		antiguedad =fechaIngreso.darDiferenciaEnMeses( getFechaActual() ) / 12;
		return antiguedad;
	}


	/* --------------------------------------------------------------------
		     Metodo funcional calcule la edad del empleado en años
	-----------------------------------------------------------------------*/	

	public int calcularEdad() {

		Fecha fechaActual =getFechaActual( );
		int edad=0;
		edad =fechaNacimiento.darDiferenciaEnMeses( getFechaActual() ) / 12;
		return edad;
	}


	/* ---------------------------------------------------------------------------
	   	      metodo funcional calcular prestaciones = antiguedad*salario/12
	------------------------------------------------------------------------------*/

	public double calcularPrestaciones() {

		int antiguedad = calcularAntiguedad( );
		double prestaciones = ( ( double ) ( antiguedad * salario ) ) / 12;
		return prestaciones;
	}


	/* -------------------------------------------------------------------------------
	      Dar la información del empleado con los valores dados por parámetro.
	----------------------------------------------------------------------------------*/

	public void setEmpleado(String pNombreEmpleado, String pApellidoEmpleado, int pGenero, String pImagen, double pSalario) {

		nombreEmpleado= pNombreEmpleado;
		apellidoEmpleado= pApellidoEmpleado;
		genero= pGenero;
		imagen= pImagen;
		salario = pSalario;
	}


	/* ----------------------------------------------------------------------------
	       Dar la información del empleado con los valores dados por parámetro.
	-------------------------------------------------------------------------------*/

	public void setSalario(double pSalario) {

		salario= pSalario;
	}


	/* ------------------------------------------------------------------------
	 		metodo permite visualizar la informacion del empleado
	---------------------------------------------------------------------------*/

	public void mostrarDatos() {

		System.out.println("\t\t╔════════════════════════════════════════╗" );
		System.out.println("\t\t║           Datos del empleado           ║");
		System.out.println("\t\t╚════════════════════════════════════════╝");
		System.out.println("\t\t Nombre: " + nombreEmpleado);
		System.out.println("\t\t Apellido: " +apellidoEmpleado );
		System.out.println("\t\t Genero: " + genero); 
		System.out.println("\t\t Edad: " + calcularEdad()); 
		System.out.println("\t\t Salario: " + salario); 
		System.out.println("\t\t Prestaciones: " + calcularPrestaciones()); 
		System.out.println("\t\t Antiguedad: " + calcularAntiguedad()); 
	}    

}
