package mundo;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.InputMismatchException;


public class Principal {

	public static void main(String[] args) {

		/* -----------------------------------------------------------------
					instanciar objetos con la clase Scanner 
		-------------------------------------------------------------------*/

		Scanner dato = new Scanner(System.in);
		Scanner sn = new Scanner(System.in);


		/* ----------------------------------------------------------------------------------------------
				Declarar variables para poder pedir al usuario los datos del empleado e ingresar
		-------------------------------------------------------------------------------------------------*/
		Empleado empleado1 = null;


		/* -----------------------------------------------------------------
		       Declarar variables para los datos del empleado
		-------------------------------------------------------------------*/

		String nombreEmple = " ";
		String apellidoEmple=" ";
		int genero = 0; // 1 Femenino || 2 Masculino
		String imagen;
		double salario = 0;
		Fecha fechaNac;
		Fecha fechaIngreso;
		int dia=0, mes = 0 ,anio=0;
		int dias=0, meses=0 ,anios=0;
		boolean salir=false;
		boolean salir1=false;
		Boolean terminar= false;



		/* -----------------------------------------------------------------
		        Variable que lee la sentencia switch
		-------------------------------------------------------------------*/
		int opcion=0;

		while (terminar == false) {


			try { 

				System.out.println("\n\t\t╔══════════════════════════════════════════════════════╗" );
				System.out.println("\t\t║                         Menu                         ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 1) Ingresar datos del empleado                       ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 2) Calcular la edad del empleado                     ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 3) Calcular la antiguedad del empleado en la empresa ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 4) Calcular las prestaciones del empleado            ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 5) Visualizar la informacion del empleado            ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝");
				System.out.println("\t\t║ 6) Salir del programa                                ║");
				System.out.println("\t\t╚══════════════════════════════════════════════════════╝\n");
				System.out.print  ("\t\t Digite su opcion: ");
				opcion=dato.nextInt();

				if (opcion == 1 || opcion ==6){ 

					switch(opcion) {

					case 1:
						System.out.println("\n\t\t1.Ingreso de datos del empleado\n");

				/* ----------------------------------------------------------------------------------------
			      									Nombre
				------------------------------------------------------------------------------------------*/

						while(salir == false) {
							try {
								System.out.print("\t\t Nombre: ");
								nombreEmple=dato.next();
								Pattern pattern=Pattern.compile("^[A-Z|a-z]{1,20}$");
								Matcher mather=pattern.matcher(nombreEmple);

								if(mather.find()) {
									salir=true;
								}
								else {
									System.out.println("\t\t➤ Error :Solo ingrese letras.");
								}
							}catch(java.util.regex.PatternSyntaxException e) {

							}
						}
						dato.nextLine();


				/* ----------------------------------------------------------------------------------------
	            									Apellido
				------------------------------------------------------------------------------------------*/


						while(salir1 == false) {
							try {
								System.out.print("\t\t Apellido: ");
								apellidoEmple=dato.next();
								Pattern pattern=Pattern.compile("^[A-Z|a-z]{1,20}$");
								Matcher mather=pattern.matcher(apellidoEmple);

								if(mather.find()) {
									salir1=true;
								}
								else {
									System.out.println("\t\t➤ Error :Solo ingrese letras.");
								}
							}catch(java.util.regex.PatternSyntaxException e) {

							}
						}
						dato.nextLine();


			    /* ----------------------------------------------------------------------------------------
										       		Genero
				------------------------------------------------------------------------------------------*/

						do {
							try {
								System.out.print("\t\t Genero 1)Femenino o 2) Masculino: ");
								genero=dato.nextInt();
								if (genero>2) {
									System.out.print("\t\t➤ Error : Solo se admiten numeros entre 1 y 2");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Debe ingresar solo numeros ");
								dato.nextLine();
							}
						}while(genero < 1 || genero > 2);



				/* ----------------------------------------------------------------------------------------
		     										Salario
				-----------------------------------------------------------------------------------------*/


						while(salir == false) {
							try {
								System.out.print("\t\t Ingrese el salario:");
								salario=dato.nextDouble();
								salir=true;
							}catch(Exception e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}

						
				/* ----------------------------------------------------------------------------------------
		       	                             Fecha de naciemeinto: dia, mes, anio
				------------------------------------------------------------------------------------------*/

						do {
							try {
								System.out.print("\n\t\t Ingrese su dia de nacimiento:");
								dia=dato.nextInt();
								if (dia <1 || dia>30) {
									System.out.print("\t\t➤ Error: Ingrese numeros entre 1 y 30");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(dia <1 || dia>30);

						do {
							try {
								System.out.print("\t\t Ingrese su mes de nacimiento:");
								mes=dato.nextInt();
								if (mes <1 || mes>12) {
									System.out.print("\t\t➤ Error: Ingrese numeros entre 1 y 12");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(mes <1 || mes>12);

						do {
							try {
								System.out.print("\t\t Ingrese su anio de nacimiento:");
								anio=dato.nextInt();
								if (anio <1 || anio>2021) {
									System.out.print("\t\t➤ Dato fuera de rango");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(anio <1 || anio>2021);

						fechaNac=new Fecha(dia,mes,anio);




				/* ----------------------------------------------------------------------------------------
                       					    Fecha de ingreso: dia, mes, anio
				------------------------------------------------------------------------------------------*/

						do {
							try {
								System.out.print("\n\t\t Ingrese su dia de ingreso:");
								dias=dato.nextInt();
								if (dias < 1 || dias > 30) {
									System.out.print("\t\t➤ Error: Ingrese un numero entre 1 y 30");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(dias < 1 || dias > 30);

						do {
							try {
								System.out.print("\t\t Ingrese su mes de ingreso:");
								meses=dato.nextInt();
								if (meses < 1 || meses > 12) {
									System.out.print("\t\t➤ Error: Ingrese un numero entre 1 y 12");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(meses <1 || meses>12);

						do {
							try {
								System.out.print("\t\t Ingrese su anio de ingreso:");
								anios=dato.nextInt();
								if (anios < 1 || anios > 2021) {
									System.out.print("\t\t➤ Dato fuera de rango");
								}
							}catch(java.util.InputMismatchException e) {
								System.out.println("\t\t➤ Solo se admiten números");
								dato.nextLine();
							}
						}while(anios < 1 || anios > 2021);


						fechaIngreso=new Fecha(dias,meses,anios);

						empleado1=new Empleado(nombreEmple,apellidoEmple,genero," ",salario,fechaNac,fechaIngreso);
						break;



					case 2:
						System.out.println("\n\t\t La edad del empleado es: " +empleado1.calcularEdad());
						break;
					case 3:
						System.out.println("\n\t\t La antiguedad del empleado es: " +empleado1.calcularAntiguedad());
						break;

					case 4:
						System.out.println("\n\t\t Sus prestaciones son: " +empleado1.calcularPrestaciones());
						break;

					case 5:
						empleado1.mostrarDatos();
						break;

					case 6:
						System.out.println("\t\t Programa finalizado con exito.");
						terminar=true;
						break;

					default:
						System.out.println("\t\t➤ Error: Ingrese solo un numero entre 1 y 6");
					}  

				}else {
					System.out.println("\t\t➤ Error: Para realizar cualquier calulo debe, primero escoger la opcion 1");
				}
			}

			catch (java.util.InputMismatchException e) {
				System.out.println("\t\t➤ Error: Ingrese solo caracteres numericos\n");
				dato.nextLine();               

			}
		}
	}
}

